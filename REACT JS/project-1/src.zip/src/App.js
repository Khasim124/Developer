import './App.css';
import FormData from './SingleComponent/FormData';
import 'bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div className="App">
      <FormData/>
    </div>
  );
}

export default App;
